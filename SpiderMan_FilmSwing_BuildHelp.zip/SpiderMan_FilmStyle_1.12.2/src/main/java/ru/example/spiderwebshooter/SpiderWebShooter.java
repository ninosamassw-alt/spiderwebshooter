package ru.example.spiderwebshooter;

import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.Item;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.registry.ForgeRegistries;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
import net.minecraftforge.fml.common.SidedProxy;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPostInitializationEvent;
import net.minecraftforge.fml.common.network.NetworkRegistry;
import net.minecraftforge.fml.common.network.simpleimpl.SimpleNetworkWrapper;
import net.minecraftforge.fml.relauncher.Side;

@Mod(modid = SpiderWebShooter.MODID, name = "Spider Web Shooter", version = "1.0.0")
@EventBusSubscriber
public class SpiderWebShooter {
    public static final String MODID = "spiderwebshooter";
    public static Item WEB_SHOOTER;

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        WEB_SHOOTER = new ItemWebShooter()
            .setRegistryName(MODID, "web_shooter")
            .setUnlocalizedName(MODID + ".web_shooter")
            .setCreativeTab(CreativeTabs.COMBAT)
            .setMaxStackSize(1);
        ForgeRegistries.ITEMS.register(WEB_SHOOTER);
        if (event.getSide() == Side.CLIENT) ClientProxy.registerModel(WEB_SHOOTER);
    }

    @Mod.EventHandler public void init(FMLInitializationEvent event) {
        GameRegistry.addShapedRecipe(
            new net.minecraft.util.ResourceLocation(MODID, "web_shooter"),
            null,
            new net.minecraft.item.ItemStack(WEB_SHOOTER),
            "ISI", " R ", "  I",
            'I', net.minecraft.init.Items.IRON_INGOT,
            'S', net.minecraft.init.Items.STRING,
            'R', net.minecraft.init.Items.REDSTONE
        );
    }
}
