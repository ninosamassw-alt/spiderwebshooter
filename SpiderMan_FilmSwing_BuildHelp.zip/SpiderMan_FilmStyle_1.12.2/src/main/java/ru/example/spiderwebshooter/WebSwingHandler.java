package ru.example.spiderwebshooter;

import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.math.Vec3d;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

/** Server-side rope constraint for a simple pendulum-style web swing. */
@Mod.EventBusSubscriber(modid = SpiderWebShooter.MODID)
public final class WebSwingHandler {
    private WebSwingHandler() {}

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || event.player.world.isRemote) return;
        if (!(event.player instanceof EntityPlayerMP)) return;
        EntityPlayerMP player = (EntityPlayerMP) event.player;
        NBTTagCompound data = player.getEntityData();
        if (!data.hasKey("SpiderWebSwing")) return;

        NBTTagCompound rope = data.getCompoundTag("SpiderWebSwing");
        Vec3d anchor = new Vec3d(rope.getDouble("X"), rope.getDouble("Y"), rope.getDouble("Z"));
        double ropeLength = Math.max(2.5D, rope.getDouble("Length"));
        Vec3d center = player.getPositionVector().add(0, player.height * 0.5D, 0);
        Vec3d offset = center.subtract(anchor);
        double distance = offset.lengthVector();
        if (distance < 0.001D) return;

        // When the player reaches beyond rope length, remove outward radial velocity and
        // gently pull the player back onto the rope radius. This lets gravity keep the swing.
        if (distance > ropeLength) {
            Vec3d radial = offset.scale(1.0D / distance);
            double excess = distance - ropeLength;
            double outwardSpeed = player.motionX * radial.x + player.motionY * radial.y + player.motionZ * radial.z;
            if (outwardSpeed > 0.0D) {
                player.motionX -= radial.x * outwardSpeed;
                player.motionY -= radial.y * outwardSpeed;
                player.motionZ -= radial.z * outwardSpeed;
            }
            double correction = Math.min(0.45D, excess * 0.35D);
            player.motionX -= radial.x * correction;
            player.motionY -= radial.y * correction;
            player.motionZ -= radial.z * correction;
            player.fallDistance = 0.0F;
            player.velocityChanged = true;
        }
    }
}
