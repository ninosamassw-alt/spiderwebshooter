package ru.example.spiderwebshooter;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.*;
import net.minecraft.util.math.*;
import net.minecraft.world.World;

public class ItemWebShooter extends Item {
    private static final int MAX_CHARGES = 8;
    private static final double RANGE = 32.0D;

    public ItemWebShooter() { setMaxStackSize(1); }

    @Override
    public ActionResult<ItemStack> onItemRightClick(World world, EntityPlayer player, EnumHand hand) {
        ItemStack stack = player.getHeldItem(hand);
        if (player.isSneaking()) {
            if (world.isRemote) return new ActionResult<>(EnumActionResult.SUCCESS, stack);
            if (player.capabilities.isCreativeMode) setCharges(stack, MAX_CHARGES);
            else {
                int needed = MAX_CHARGES - getCharges(stack), found = 0;
                for (int i = 0; i < player.inventory.getSizeInventory() && found < needed; i++) {
                    ItemStack inv = player.inventory.getStackInSlot(i);
                    if (!inv.isEmpty() && inv.getItem() == Items.STRING) {
                        int take = Math.min(needed - found, inv.getCount());
                        inv.shrink(take); found += take;
                    }
                }
                setCharges(stack, getCharges(stack) + found);
            }
            player.sendStatusMessage(new net.minecraft.util.text.TextComponentString(
                "Заряды паутины: " + getCharges(stack) + "/" + MAX_CHARGES), true);
            return new ActionResult<>(EnumActionResult.SUCCESS, stack);
        }
        if (world.isRemote) return new ActionResult<>(EnumActionResult.SUCCESS, stack);

        // ПКМ второй раз отпускает паутину; Shift+ПКМ выше оставлен для перезарядки.
        NBTTagCompound playerData = player.getEntityData();
        if (playerData.hasKey("SpiderWebSwing")) {
            playerData.removeTag("SpiderWebSwing");
            player.sendStatusMessage(new net.minecraft.util.text.TextComponentString("Паутина отпущена!"), true);
            return new ActionResult<>(EnumActionResult.SUCCESS, stack);
        }

        int charges = getCharges(stack);
        if (charges <= 0 && !player.capabilities.isCreativeMode) {
            player.sendStatusMessage(new net.minecraft.util.text.TextComponentString(
                "Нет зарядов! Shift + ПКМ — перезарядить нитями."), true);
            return new ActionResult<>(EnumActionResult.FAIL, stack);
        }

        Vec3d start = player.getPositionEyes(1.0F);
        Vec3d end = start.add(player.getLook(1.0F).scale(RANGE));
        RayTraceResult blockHit = world.rayTraceBlocks(start, end, false, true, false);
        Entity target = findEntity(player, start, end);
        Vec3d anchor = null;

        if (target != null) {
            anchor = target.getPositionVector().add(0, target.height * 0.5D, 0);
            if (target instanceof EntityLivingBase) {
                ((EntityLivingBase) target).addPotionEffect(
                    new net.minecraft.potion.PotionEffect(net.minecraft.init.MobEffects.SLOWNESS, 50, 2));
            }
        } else if (blockHit != null && blockHit.typeOfHit == RayTraceResult.Type.BLOCK) {
            BlockPos pos = blockHit.getBlockPos();
            anchor = new Vec3d(pos.getX() + 0.5D, pos.getY() + 0.5D, pos.getZ() + 0.5D);
            BlockPos webPos = pos.offset(blockHit.sideHit);
            if (world.isAirBlock(webPos)) world.setBlockState(webPos, Blocks.WEB.getDefaultState(), 3);
        }

        if (anchor != null) {
            Vec3d playerCenter = player.getPositionVector().add(0, player.height * 0.5D, 0);
            Vec3d radial = playerCenter.subtract(anchor);
            double distance = radial.lengthVector();
            if (distance > 0.1D) {
                // Store a fixed rope anchor and length. Server tick handler constrains the rope
                // while gravity and tangential momentum produce a pendulum-like swing.
                NBTTagCompound swing = new NBTTagCompound();
                swing.setDouble("X", anchor.x);
                swing.setDouble("Y", anchor.y);
                swing.setDouble("Z", anchor.z);
                swing.setDouble("Length", Math.max(2.5D, distance));
                playerData.setTag("SpiderWebSwing", swing);

                Vec3d radialDir = radial.normalize();
                Vec3d look = player.getLook(1.0F);
                Vec3d tangent = look.subtract(radialDir.scale(look.dotProduct(radialDir)));
                if (tangent.lengthVector() < 0.05D) tangent = new Vec3d(-radialDir.z, 0, radialDir.x);
                tangent = tangent.normalize();
                double launch = Math.min(1.25D, 0.55D + distance * 0.018D);
                player.motionX += tangent.x * launch;
                player.motionY += tangent.y * launch + 0.18D;
                player.motionZ += tangent.z * launch;
                player.fallDistance = 0;
                player.velocityChanged = true;
                player.sendStatusMessage(new net.minecraft.util.text.TextComponentString(
                    "Паутина зацепилась! Раскачивайся и нажми ПКМ ещё раз, чтобы отпустить."), true);
            }
            if (!player.capabilities.isCreativeMode) setCharges(stack, charges - 1);
        } else {
            player.sendStatusMessage(new net.minecraft.util.text.TextComponentString("Паутина не зацепилась."), true);
            return new ActionResult<>(EnumActionResult.FAIL, stack);
        }
        player.swingArm(hand);
        return new ActionResult<>(EnumActionResult.SUCCESS, stack);
    }

    private Entity findEntity(EntityPlayer player, Vec3d start, Vec3d end) {
        AxisAlignedBB box = player.getEntityBoundingBox()
            .expand(end.x - start.x, end.y - start.y, end.z - start.z).grow(1.0D);
        Entity best = null;
        double nearest = RANGE * RANGE;
        for (Entity e : player.world.getEntitiesWithinAABBExcludingEntity(player, box)) {
            if (!e.canBeCollidedWith()) continue;
            RayTraceResult intercept = e.getEntityBoundingBox().grow(0.3D).calculateIntercept(start, end);
            if (intercept != null) {
                double d = start.squareDistanceTo(intercept.hitVec);
                if (d < nearest) { nearest = d; best = e; }
            }
        }
        return best;
    }

    private int getCharges(ItemStack stack) {
        return stack.hasTagCompound() && stack.getTagCompound().hasKey("WebCharges")
            ? stack.getTagCompound().getInteger("WebCharges") : MAX_CHARGES;
    }
    private void setCharges(ItemStack stack, int n) {
        if (!stack.hasTagCompound()) stack.setTagCompound(new NBTTagCompound());
        stack.getTagCompound().setInteger("WebCharges", Math.max(0, Math.min(MAX_CHARGES, n)));
    }
}
